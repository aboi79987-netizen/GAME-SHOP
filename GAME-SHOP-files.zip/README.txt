GAME SHOP
=========
محتويات الملف:
- index.html: الصفحة الرئيسية للموقع.

طريقة الرفع على GitHub:
1. افتح مستودع GAME-SHOP.
2. اضغط Add file ثم Upload files.
3. فك ضغط هذا الملف على جهازك، ثم ارفع index.html.
4. اضغط Commit changes.
5. من Settings > Pages اختر Deploy from a branch ثم main و / (root)، واحفظ.
6. بعد النشر سيكون الرابط غالباً:
   https://aboi79987-netizen.github.io/GAME-SHOP/

ملاحظة: أضف رقم واتساب وروابط التواصل الحقيقية داخل قسم "تواصل معنا" قبل النشر.
